<div class="category-wrap mb-30">
                                <h3 class="sidebar-title">Quick Menu</h3>
                                <ul>
                                    <li><a href="{{url('/clientarea/')}}"><i class="fa fa-home"></i> Home</a></li>
                                    <li><a href="{{url('/clientarea/orders')}}"><i class="fa fa-money"></i> Orders</a></li>
                                    <li><a href="{{url('/clientarea/profile')}}"><i class="fa fa-user"></i> Profile</a></li>
                                    <li><a href="{{url('/clientarea/logout')}}"><i class="fa fa-power-off"></i> Logout</a></li>
                                   
                                </ul>
                            </div>