<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

<!-- BEGIN HEAD -->
<head>
     <meta charset="UTF-8" />
    <title>BCORE Admin Dashboard Template | Under Construction</title>
     <meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
     <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <!-- GLOBAL STYLES -->
    <!-- GLOBAL STYLES -->
    <link rel="stylesheet" href="{{asset('admins_theme/assets/plugins/bootstrap/css/bootstrap.css')}}" />
    <link rel="stylesheet" href="{{asset('admins_theme/assets/plugins/Font-Awesome/css/font-awesome.css')}}" />
    <!--END GLOBAL STYLES -->

     <!-- PAGE LEVEL STYLES -->
        <link rel="stylesheet" href="{{asset('admins_theme/assets/css/countdown.css')}}" />
     <!-- END PAGE LEVEL STYLES -->
       <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
    <!-- END HEAD -->
    <!-- BEGIN BODY -->
<body >
      <!--MAIN CONTAINER --> 
    <div id="main"> 
        <!-- PAGE CONTENT --> 
      <div class="container">
       
        <div class="clearfix">
         
        </div>
        <div id="counter"></div>

        <div id="counter-default" class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="inner">
                    <div id="day-number" class="timer-number"></div>
                    <div class="timer-text">DAYS</div>
                    <div class="progress mini progress-striped active">
                        <div id="day-bar" class="progress-bar progress-bar-primary"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="inner">
                    <div id="hour-number" class="timer-number"></div>
                    <div class="timer-text">HOURS</div>
                    <div class="progress mini progress-striped active">
                        <div id="hour-bar" class="progress-bar progress-bar-primary"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="inner">
                    <div id="minute-number" class="timer-number"></div>
                    <div class="timer-text">MINUTES</div>
                    <div class="progress mini progress-striped active">
                        <div id="minute-bar" class="progress-bar progress-bar-primary"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="inner">
                    <div id="second-number" class="timer-number"></div>
                    <div class="timer-text">SECOND</div>

                    <div class="progress mini progress-striped active">
                        <div id="second-bar" class="progress-bar progress-bar-primary"></div>
                    </div>

                </div>
            </div>
        </div>
           <div class="col-lg-12 title">
            <h2  >Our Site Is <span class="">U</span>nder <span class="">C</span>onstruction</h2>
          We are done with the backend just front end to go.
          </div>
          <br /><br />
        <div class="row">
          <div class="col-lg-12">
            <div class="progress progress-striped active" rel="tooltip" data-placement="bottom"
                 data-original-title="Total Progress">
              <div id="total-bar" class="progress-bar progress-bar-primary"></div>
            </div>
          </div>
        </div>
        <hr/>
        <div class="row">
          <div class="col-lg-6">
            <form action="#" method="post" accept-charset="utf-8" id="emailForm">
            
		<div class="form-group">
                    <label class="control-label" for="email1">E-mail</label>
                      <input class="form-control" type="email" name="email1" id="email1"
                             placeholder="Enter your email to subscribe" required />
                  </div>
                  <div class="row">
		    <div class="form-group col-lg-6 col-sm-6 col-6">
		      <button class="btn btn-primary btn-block" type="submit">Submit</button>
		    </div>
		    <div class="form-group col-lg-6 col-sm-6 col-6">
		      <button class="btn btn-block btn-success" type="reset">Cancel</button>
		    </div>
                  </div>
		  
            </form>
          </div>
          <div class="col-lg-6 contact">
          {{ config('app.name', 'Laravel') }}
          </div>
        </div>
        
      </div>
          <!--END PAGE CONTENT --> 
    </div>
     <!--END MAIN CONTAINER --> 
	      

     <!-- GLOBAL SCRIPTS -->
    <script src="{{asset('admins_theme/assets/plugins/jquery-2.0.3.min.js')}}"></script>
    <!-- END GLOBAL SCRIPTS -->

	       <!-- PAGE LEVEL SCRIPTS --> 
      <script src="{{asset('admins_theme/assets/plugins/bootstrap/js/bootstrap.min.js')}}"></script>
          <script type="text/javascript" src="{{asset('admins_theme/assets/plugins/countdown/jquery.countdown.min.js')}}"></script>
            
    <script type="text/javascript" src="{{asset('admins_theme/assets/plugins/jquery-validation-1.11.1/dist/jquery.validate.min.js')}}"></script>
    
    <script type="text/javascript" src="{{asset('admins_theme/assets/js/countdown.js')}}"></script>
     <!-- END PAGE LEVEL SCRIPTS --> 


</body>
    <!-- END BODY -->
</html>
