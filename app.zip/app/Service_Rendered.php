<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Service_Rendered extends Model
{
    public $table = 'service_delivered';
}
